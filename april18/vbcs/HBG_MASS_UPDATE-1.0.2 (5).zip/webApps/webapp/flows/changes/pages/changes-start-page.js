define([], () => {
  'use strict';

  class PageModule {

    StringigyArray(val) {
      return val.toString();
    }

    GenerateCSVAction(data) {
      var obj = data;
      var array = [];
      for (var i = 0; i < obj.length; i++) {
        for (var key in obj[i]) {
          if (obj[i].hasOwnProperty(key)) {
            obj[i][key.charAt(0).toUpperCase() + key.substring(1)] = obj[i][key];
            delete obj[i][key];
          }
        }
        array.push(obj[i]);
      }
      console.log(array);
      var keys = Object.keys(array[0]);
      var result = '';
      result += keys.join(',');
      result += '\n';
      data.forEach(function (item) {
        keys.forEach(function (key) {
          result += item[key] + ',';
        });
        result += '\n';
      });
      var csv = 'data:text/csv;charset=utf-8,' + result;
      var excel = encodeURI(csv);
      var link = document.createElement('a');
      link.setAttribute('href', excel);
      link.setAttribute('download', "New Sales Orders.csv");
      link.click();
    }

    // GenerateCSVAction(data) {
    //   var keys = Object.keys(data[1]);
    //   var result = '';
    //   result += keys.join(',');
    //   result += '\n';
    //   data.forEach(function (item) {
    //     keys.forEach(function (key) {
    //       result += item[key] + ',';
    //     });
    //     result += '\n';
    //   });
    //   var csv = 'data:text/csv;charset=utf-8,' + result;
    //   var excel = encodeURI(csv);
    //   var link = document.createElement('a');
    //   link.setAttribute('href', excel);
    //   link.setAttribute('download', "New Sales Orders.csv");
    //   link.click();
    // }
  }

  return PageModule;
});
