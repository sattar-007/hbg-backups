define([], () => {
  'use strict';

  class AppModule {

    GenerateCSVAction(data, filename) {
      var keys = Object.keys(data[0]);
      var result = '';
      result += keys.join(',');
      result += '\n';
      data.forEach(function (item) {
        keys.forEach(function (key) {
          result += item[key] + ',';
        });
        result += '\n';
      });
      var csv = 'data:text/csv;charset=utf-8,' + result;
      var excel = encodeURI(csv);
      var link = document.createElement('a');
      link.setAttribute('href', excel);
      link.setAttribute('download', filename);
      link.click();
    }

    getSysdate() {
      var date = "";
      let today = new Date();
      let yesterday = new Date();
      yesterday.setDate(today.getDate() - 2);
      date = yesterday.toISOString();
      return date;
    };

    validateGroup(id) {
      var tracker = document.getElementById(id);
      if (tracker.valid === "valid") {
      }
      else if (tracker.valid.startsWith("invalid")) {
        if (tracker.valid === "invalidHidden") {
          tracker.showMessages();
        }
        tracker.focusOn("@firstInvalidShown");
      }
      return tracker.valid;
    };




  };



  return AppModule;
});
