define([], () => {
  'use strict';

var PageModule = function PageModule() { };


  PageModule.prototype.preparePayload_ShipSchTemp = function (
    ShipSchTemp) {
    var payload = null;
    payload = '{"shipping_schedule_type":"' + ShipSchTemp.shipping_schedule_type +
    '",				"add_items_automatically":"' + ShipSchTemp.add_items_automatically + 
    '",				"remove_items_automatically":"' + ShipSchTemp.remove_items_automatically + 
    '",				"on_sale_date_editable":"' + ShipSchTemp.on_sale_date_editable + 
    '",				"on_sale_date_required":"' + ShipSchTemp.on_sale_date_required + 
  '",				"release_date_editable":"' + ShipSchTemp.release_date_editable + 
  '",				"release_date_required":"' + ShipSchTemp.release_date_required + 
  '",				"release_date_subtract_from_osd":"' + ShipSchTemp.release_date_subtract_from_osd + 
  '",				"cutoff_date_editable":"' + ShipSchTemp.cutoff_date_editable + 
  '",				"cutoff_date_required":"' + ShipSchTemp.cutoff_date_required + 
  '",				"cutoff_date_subtract_from_release_date":"' + ShipSchTemp.cutoff_date_subtract_from_release_date + 
  '",				"cleanup_release_date_editable":"' + ShipSchTemp.cleanup_release_date_editable + 
  '",				"cleanup_release_date_required":"' + ShipSchTemp.cleanup_release_date_required + 
  '",				"cleanup_release_date_subtract_from_osd":"' + ShipSchTemp.cleanup_release_date_subtract_from_osd + 
  '",				"created_by":"' + ShipSchTemp.created_by + 
  '",				"last_updated_by":"' + ShipSchTemp.last_updated_by + '" }';
    return payload;
  };
  return PageModule;
});
