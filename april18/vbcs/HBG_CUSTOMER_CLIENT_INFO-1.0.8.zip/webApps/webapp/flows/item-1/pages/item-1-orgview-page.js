/**
 * Copyright (c)2020, 2023, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */
define(['knockout',
  'ojs/ojknockout-keyset',
  'ojs/ojarraytreedataprovider'
], function (ko, keySet, ArrayTreeDataProvider) {
  'use strict';

  let navigationMenu = [];



  var PageModule = function PageModule() {

    PageModule.prototype.StringigyArray = function (val) {
      return val.toString();
    }

    PageModule.prototype.ArraytoString = function (val) {
      var a = val;
      var set = a.replace(/\[|\]/g, '').split(',');
      console.log(set);
      return set;
    }

    PageModule.prototype.Treedatagenerator = function (restdata, organization, party_number) {
      var items = [];
      var navigationMenu = [];
      for (let i = 0; i < restdata.length; i++) {
        var obj = {
          "id": "Accounts",
          "label": restdata[i].account_number,
          "icon": restdata[i].account_number,
          "badge": ""
        };
        items.push(obj);
      }
      // if (organization !== "" && organization !== null && typeof organization !== "undefined") {
      navigationMenu = [
        {
          "id": "Organization",
          "label": "Organization",
          "icon": "education",
          "node": "parent",
          "items": [
            {
              "id": "Org",
              "label": party_number,
              "icon": party_number + "- " + organization,
              "badge": ""
            }
          ]
        },
        {
          "id": "",
          "label": "Accounts",
          "icon": "education",
          "node": "parent",
          "items": items
        }
        ,
        {
          "id": "Sites",
          "label": "Sites",
          "icon": "book",
          "node": "parent",
          "items": []
        }
      ];

      // } else {
      //   navigationMenu = [
      //     {
      //       "id": "",
      //       "label": "Accounts",
      //       "icon": "education",
      //       "node": "parent",
      //       "items": items
      //     }
      //     ,
      //     {
      //       "id": "Sites",
      //       "label": "Sites",
      //       "icon": "book",
      //       "node": "parent",
      //       "items": []
      //     }
      //   ];
      // }


      return navigationMenu;
    };

    PageModule.prototype.Treedatageneratorsites = function (restdata, organization, party_number, sitesdata) {
      var items = [];
      for (let i = 0; i < restdata.length; i++) {
        var obj = {
          "id": "Accounts",
          "label": restdata[i].account_number,
          "icon": restdata[i].account_number,
          "badge": ""
        };
        items.push(obj);
      }
      var sitesArray = [];
      var navigationMenu = [];
      for (let i = 0; i < sitesdata.length; i++) {
        var siteobj = {
          "id": "Sites",
          "label": sitesdata[i].party_site_number,
          "icon": sitesdata[i].party_site_number + "-" + sitesdata[i].party_site_name,
          "badge": ""
        };
        sitesArray.push(siteobj);
      }
      // if (organization !== "" && organization !== null && typeof organization !== "undefined") {
      navigationMenu = [
        {
          "id": "Organization",
          "label": "Organization",
          "icon": "education",
          "node": "parent",
          "items": [
            {
              "id": "Org",
              "label": organization,
              "icon": party_number + "- " + organization,
              "badge": ""
            }
          ]
        },
        {
          "id": "Account",
          "label": "Account",
          "icon": "",
          "node": "parent",
          "items": items
        },
        {
          "id": "Site",
          "label": "Sites",
          "icon": "",
          "node": "parent",
          "items": sitesArray
        },
      ];
      // } else {
      //   navigationMenu = [
      //     {
      //       "id": "Account",
      //       "label": "Account",
      //       "icon": "",
      //       "node": "parent",
      //       "items": items
      //     },
      //     {
      //       "id": "Site",
      //       "label": "Sites",
      //       "icon": "",
      //       "node": "parent",
      //       "items": sitesArray
      //     },
      //   ];
      // }
      return navigationMenu;
    };



    this.metadata = {
      navigationMenu: navigationMenu
    };
    PageModule.prototype.getMetadata = function () {
      return this.metadata;
    };

    PageModule.prototype.getNavigationContent = function (metadata) {
      // if (this.navigationContent === undefined) {
      this.navigationContent = ko.observable();
      this.navigationContent("");
      this.navigationContent(new ArrayTreeDataProvider(
        this._getNavigationData(
          metadata), {
        keyAttributes: 'attr.id'
      }));
      // }
      var sample = this.navigationContent;
      return sample;

    };



    PageModule.prototype._getNavigationData = function (menu) {
      var navData = [],
        self = this;

      for (var i = 0; i < menu.length; i++) {
        var menuItem = {};
        var origMenuItem = menu[i];
        if (typeof origMenuItem === "object") {
          menuItem["attr"] = {
            "id": origMenuItem.id,
            "name": origMenuItem.label,
            "icon": origMenuItem.icon,
            "badge": origMenuItem.badge,
            "node": origMenuItem.node
          };
        }
        if (origMenuItem.items && origMenuItem.items.length > 0)
          menuItem["children"] = this._getNavigationData(origMenuItem.items);
        navData.push(menuItem);
      }
      return navData;
    };

    PageModule.prototype.itemSelectable = function (context) {
      return context['leaf'];
    };

    this.navlistExpanded = new keySet.ObservableKeySet();

  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.Test = function (data) {
    console.log(">>>>>" + ", " + JSON.stringify(data));
  };


  return PageModule;
});
