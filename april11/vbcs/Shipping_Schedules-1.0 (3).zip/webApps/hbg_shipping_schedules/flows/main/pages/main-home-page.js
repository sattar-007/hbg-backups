define([], () => {
  'use strict';

  var PageModule = function PageModule() { };

PageModule.prototype.preparePayload_UpdateReservation = function (UpdateReservation) 
{
    var payload = null;
    console.log("ReservationNumber in Update function" + UpdateReservation.pre_reservation_number);
    payload = '{"ReservationNum":"' + UpdateReservation.pre_reservation_number + '" }';
    return payload;
  };
  
  return PageModule;
});
