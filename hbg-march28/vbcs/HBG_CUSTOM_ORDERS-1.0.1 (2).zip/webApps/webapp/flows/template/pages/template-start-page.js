define([], () => {
  'use strict';

  class PageModule {
  }
  PageModule.prototype.getsysdate = function () {
    return new Date().toISOString();
  };
  PageModule.prototype.dateformatter = function (date) {
    if (date !== "" && date !== null && date !== "undefined") {
      let yourDate = new Date(date);
      var result = yourDate.toISOString().split('T')[0];
      return result;
    } else {
      return "";
    }
  };

  return PageModule;
});
