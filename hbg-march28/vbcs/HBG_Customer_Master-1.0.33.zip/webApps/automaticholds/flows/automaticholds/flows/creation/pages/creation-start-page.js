define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.closePopup = function(event)
  {
    document.getElementById('WhoColumns').close();
  };
  
   PageModule.prototype.openPopup = function(event)
  {
    document.getElementById('WhoColumns').open();
  };

 PageModule.prototype.getlocaldate = function(Inputdate) {
     var todaydate = new Date(Inputdate);
     var locale = 'en-US';
  return todaydate.toLocaleDateString(locale);
  
  };

   PageModule.prototype.preparePayload_UpdateDate = function (
    updateRule) {
    var payload = null;
    payload = '{"Rule_id":"' + updateRule.RuleID +
    '",				"Comments":"' + updateRule.Comments + 
    '",				"AutoReleaseFlag":"' + updateRule.AutoReleaseFlag + 
    '",				"End_Date":"' + updateRule.EndDate +  '" }';
    return payload;
  };
  
   PageModule.prototype.preparePayload_UpdateDateORDS = function (
    updateRule,last_updated_by) {
    var payload = null;
    var p_enddate = '';
    var p_comments = '';
    var p_autorelaseflag = '';
    var p_holdcomments = '';
    var p_department = '';
    if(updateRule.end_date == null || updateRule.end_date == 'Invalid Date' )
    {
     p_enddate = '';
    }
    else
    {
   /*   p_enddate =  PageModule.prototype.getlocaldate( updateRule.EndDate) ; */
    p_enddate = updateRule.end_date.substr(0,10);
    }
    if(updateRule.comments == null)
    {
     p_comments = '';
    }
    else
    {
      p_comments = updateRule.comments;
    }
    if(updateRule.auto_release_flag == null)
    {
     p_autorelaseflag = '';
    }
    else
    {
      p_autorelaseflag = updateRule.auto_release_flag;
    }
    if(updateRule.hold_comments == null)
    {
     p_holdcomments = '';
    }
    else
    {
      p_holdcomments = updateRule.hold_comments;
    }
    if(updateRule.department == null)
    {
     p_department = '';
    }
    else
    {
      p_department = updateRule.department;
    }
    payload = '{"p_comments":"' + p_comments + 
    '",				"p_autoreleaseflag":"' + p_autorelaseflag + 
    '",				"p_end_date":"' + p_enddate +
    '",				"p_rule_id":"' + updateRule.rule_id +
    '",				"p_last_updated_by":"' + last_updated_by + 
    '",				"p_hold_comments":"' + p_holdcomments +
    '",				"p_department":"' + p_department +   '" }';
    return payload;
  };

  return PageModule;
});
