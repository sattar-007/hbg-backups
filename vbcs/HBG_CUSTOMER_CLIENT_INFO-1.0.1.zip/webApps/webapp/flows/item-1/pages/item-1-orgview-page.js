define([], () => {
  'use strict';

  class PageModule {

  }
    PageModule.prototype.Treedatagenerator = function (restdata, organization) {
      var items = [];
      for (let i = 0; i < restdata.length; i++) {
        var obj = {
          "id": restdata[i].account_number,
          "label": restdata[i].account_number,
          "icon": "",
          "badge": ""
        };
        items.push(obj);
      }
      
      // var navigationMenu = [
      //   {
      //     "id": "gettingstarted",
      //     "label": organization,
      //     "icon": "education",
      //     "node": "parent",
      //     "items": items
      //   }
      // ];

      return items;
    };



  return PageModule;
});
