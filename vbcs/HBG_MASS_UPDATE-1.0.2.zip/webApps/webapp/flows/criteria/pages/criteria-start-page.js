define([], () => {
  'use strict';

  class PageModule {
    StringigyArray(val) {
      return val.toString();
    }
  }

  return PageModule;
});
