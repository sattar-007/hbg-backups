define([], () => {
  'use strict';

  class AppModule {
        GenerateCSVAction(data) {
      var keys = Object.keys(data[0]);
      
      var result = '';
      result += keys.join(',');
      result += '\n';
      data.forEach(function (item) {
        keys.forEach(function (key) {
          result += item[key] + ',';
        });
        result += '\n';
      });
      var csv = 'data:text/csv;charset=utf-8,' + result;
      var excel = encodeURI(csv);
      var link = document.createElement('a');
      link.setAttribute('href', excel);
      link.setAttribute('download', "New Data.csv");
      link.click();
    }
  }
  
  return AppModule;
});
