define([], () => {
  'use strict';

  var PageModule = function PageModule() { };

  PageModule.prototype.createResNum = function () {
    var d = Math.floor(Math.random() * Math.floor(Math.random() * Date.now()));
    console.log(d);
    return d;
  };

  

  PageModule.prototype.preparePayload_LotNumber = function (
    lot_number,subinventory_code,transaction_quantity) {
    var payload = null;
    
    payload = '{"lot_number":"' + lot_number +
    '",				"subinventory_code":"' + subinventory_code + 
	'",				"transaction_quantity":"' + transaction_quantity +'" }';
    return payload;
  };

 PageModule.prototype.getColor = function (submitted){
    if (submitted !== 0)
    return {"color":"blue"};
  };

  PageModule.prototype.getsysdate = function () {
    return new Date().toISOString();
  };

  PageModule.prototype.dateformatter = function (date) {
    if (date !== "" && date !== null && date !== "undefined") {
      // var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
      //   "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
      // var t = new Date(date);
      // return t.getFullYear() + '-' + t.getMonth() + '-' + t.getDate();
      let yourDate = new Date(date);
      var result = yourDate.toISOString().split('T')[0];
      return result;
    } else {
      return "";
    }
  };


  return PageModule;
});
