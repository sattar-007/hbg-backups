define([], () => {
  'use strict';

  class PageModule {
    getsysdate() {
     return new Date().toISOString();
    };
  }

  return PageModule;
});
