define([], () => {
  'use strict';

  class PageModule {

  }
  PageModule.prototype.log = function (arg1) {
    console.log("---------------LOG !!! ----------------");
    console.log(arg1);
  };

  PageModule.prototype.sysdateJsonFormat = function () {
    let currentSysdate = new Date();
    return currentSysdate.toJSON();
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.initiateADPPaymentTable = function (batchID) {
    let paymentLine = "";

    let paymentArray = [];

    for (var i = 0; i < 50; i++) {
        paymentLine = {
            P_ACCOUNT_NAME: "",
            P_ACCOUNT_NUMBER: "",
            P_BATCH_ID: batchID,
            P_BUSINESS_UNIT: "HBG US BU",
            P_CREATE_STATUS: "",
            P_CREATED_BY: "",
            P_CURRENCY: "USD",
            P_GL_ACCOUNT: "",
            P_LAST_UPDATED_BY: "",
            P_PAYMENT_DATE: "",
            P_PAYMENT_METHOD: "",
            P_PAYMENT_TYPE: "Standard",
            P_PROCESS_TYPE: "RECEIPT IMPORT",
            P_RECEIPT_NUMBER: "",
            P_LINE_KEY: i
        };
      paymentArray.push(paymentLine);
      // more statements
    };
    return paymentArray;
  };

  PageModule.prototype.initiateADPPaymentTableEditMode = function (batchArray) {
    let paymentLine = "";
    let paymentArray = [];
    for (let i = 0; i < batchArray.length; i++) {
        paymentLine = {
            P_LINE_ID: batchArray[i].line_id,
            P_ACCOUNT_NAME: batchArray[i].account_name,
            P_ACCOUNT_NUMBER: batchArray[i].account_number,
            P_AMOUNT: batchArray[i].amount,
            P_BATCH_ID: batchArray[i].batch_id,
            P_BUSINESS_UNIT: batchArray[i].business_unit,
            P_RETURN_STATUS: batchArray[i].return_status,
            P_CREATED_BY: batchArray[i].created_by,
            P_CURRENCY: batchArray[i].currency,
            P_GL_ACCOUNT: batchArray[i].gl_account,
            P_LAST_UPDATED_BY: batchArray[i].last_updated_by,
            P_PAYMENT_DATE: batchArray[i].payment_date,
            P_PAYMENT_METHOD: batchArray[i].payment_method,
            P_PAYMENT_TYPE: batchArray[i].payment_type,
            P_PROCESS_TYPE: "RECEIPT IMPORT",
            P_RECEIPT_NUMBER: batchArray[i].receipt_number,
            P_LINE_KEY: i,
            P_RETURN_MESSAGE: batchArray[i].return_message
        };
      paymentArray.push(paymentLine);
      // more statements
    };
    return paymentArray;
  };

  PageModule.prototype.updateADPBusinessUnit = function (currentBUKey, currentBUValue, updateADP) {
    let auxUpdateADP = updateADP[currentBUKey];
    auxUpdateADP.P_BUSINESS_UNIT = currentBUValue;
    return auxUpdateADP;
  };

  PageModule.prototype.updateADPPaymentType = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_PAYMENT_TYPE = currentValue;
    return auxUpdateADP;
  };

  PageModule.prototype.updateADPPaymentDate = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_PAYMENT_DATE = currentValue;
    return auxUpdateADP;
  };

  PageModule.prototype.updateADPAccountNumber = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_ACCOUNT_NUMBER = currentValue;
    return auxUpdateADP;
  };

  
  PageModule.prototype.updateADPAccountName = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_ACCOUNT_NAME = currentValue;
    return auxUpdateADP;
  };
  
  PageModule.prototype.updateADPReceiptNumber = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_RECEIPT_NUMBER = currentValue;
    return auxUpdateADP;
  };
  
  PageModule.prototype.updateADPAmount = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_AMOUNT = currentValue;
    return auxUpdateADP;
  };
  
  PageModule.prototype.updateADPPayMethod = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_PAYMENT_METHOD = currentValue;
    return auxUpdateADP;
  };
  
  PageModule.prototype.updateADPCurrency = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_CURRENCY = currentValue;
    return auxUpdateADP;
  };
  
  PageModule.prototype.updateADPGLAccount = function (currentKey, currentValue, updateADP) {
    let auxUpdateADP = updateADP[currentKey];
    auxUpdateADP.P_GL_ACCOUNT = currentValue;
    return auxUpdateADP;
  };
  
  PageModule.prototype.validatePaymentRow = function (paymentRow) {
    if(paymentRow.P_PAYMENT_TYPE === 'Standard'){
      if(
        paymentRow.P_ACCOUNT_NAME != "" && paymentRow.P_ACCOUNT_NAME != undefined &&
        paymentRow.P_ACCOUNT_NUMBER != "" && paymentRow.P_ACCOUNT_NUMBER != undefined &&
        paymentRow.P_AMOUNT != "" && paymentRow.P_AMOUNT != undefined &&
        paymentRow.P_BATCH_ID != "" && paymentRow.P_BATCH_ID != undefined &&
        paymentRow.P_BUSINESS_UNIT != "" && paymentRow.P_BUSINESS_UNIT != undefined &&
        paymentRow.P_CURRENCY != "" && paymentRow.P_CURRENCY != undefined &&
        paymentRow.P_PAYMENT_DATE != "" && paymentRow.P_PAYMENT_DATE != undefined &&
        paymentRow.P_PAYMENT_METHOD != "" && paymentRow.P_PAYMENT_METHOD != undefined &&
        paymentRow.P_PAYMENT_TYPE != "" && paymentRow.P_PAYMENT_TYPE != undefined &&
        paymentRow.P_RECEIPT_NUMBER != "" && paymentRow.P_RECEIPT_NUMBER != undefined &&
        paymentRow.P_RETURN_STATUS != "PROCESSED"
        ){
        return true;
      }
    }
    else if(paymentRow.P_PAYMENT_TYPE === 'Miscellaneous'){
      if(
        paymentRow.P_AMOUNT != "" && paymentRow.P_AMOUNT != undefined &&
        paymentRow.P_BATCH_ID != "" && paymentRow.P_BATCH_ID != undefined &&
        paymentRow.P_BUSINESS_UNIT != "" && paymentRow.P_BUSINESS_UNIT != undefined &&
        paymentRow.P_CURRENCY != "" && paymentRow.P_CURRENCY != undefined &&
        paymentRow.P_PAYMENT_DATE != "" && paymentRow.P_PAYMENT_DATE != undefined &&
        paymentRow.P_PAYMENT_METHOD != "" && paymentRow.P_PAYMENT_METHOD != undefined &&
        paymentRow.P_PAYMENT_TYPE != "" && paymentRow.P_PAYMENT_TYPE != undefined &&
        paymentRow.P_RECEIPT_NUMBER != "" && paymentRow.P_RECEIPT_NUMBER != undefined &&
        paymentRow.P_RETURN_STATUS != "PROCESSED"
        ){
        return true;
      }      
    }
    return false;
  };

  return PageModule;
});
