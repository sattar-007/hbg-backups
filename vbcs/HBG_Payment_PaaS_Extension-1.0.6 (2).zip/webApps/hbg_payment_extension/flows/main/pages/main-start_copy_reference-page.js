define([], () => {
  'use strict';

  class PageModule {

  }
  PageModule.prototype.getsysdate = function () {
    return new Date().toISOString();
  };
  
  PageModule.prototype.dateformatter = function (date) {
    if (date !== "" && date !== null && date !== "undefined") {
      var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
        "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
      var t = new Date(date);
      return t.getFullYear() + '-' + t.getMonth() + '-' + t.getDate();
    } else {
      return "";
    }
  };

  PageModule.prototype.preparePayload_InsertSFData = function (
    sf_maintenance_id,
    sales_force_number,
    sales_force_name,
    company,
    edelweiss,
    external_checkbox,
    notes,
    entered_by,
    updated_by,
    start_date,
    end_date,
    status,
    sales_force_id) {

    if (sf_maintenance_id == 'undefined' || sf_maintenance_id == null) {
      sf_maintenance_id = '';
    }
    if (sales_force_number == 'undefined' || sales_force_number == null) {
      sales_force_number = '';
    }
    if (sales_force_name == 'undefined' || sales_force_name == null) {
      sales_force_name = '';
    }
    if (company == 'undefined' || company == null) {
      company = '';
    }
    if (edelweiss == 'undefined' || edelweiss == null) {
      edelweiss = '';
    }
    if (external_checkbox == 'undefined' || external_checkbox == null) {
      external_checkbox = '';
    }
    if (notes == 'undefined' || notes == null) {
      notes = '';
    }
    if (entered_by == 'undefined' || entered_by == null) {
      entered_by = '';
    }
    if (updated_by == 'undefined' || updated_by == null) {
      updated_by = '';
    }
    if (start_date == 'undefined' || start_date == null) {
      start_date = '';
    }
    if (end_date == 'undefined' || end_date == null) {
      end_date = '';
    }
    if (status == 'undefined' || status == null) {
      status = '';
    }
    if (sales_force_id == 'undefined' || sales_force_id == null) {
      sales_force_id = '';
    }
    var payload = null;
    payload = {
      "P_SF_MAINTENANCE_ID": sf_maintenance_id,
      "P_SALES_FORCE_NUMBER": sales_force_number,
      "P_SALES_FORCE_NAME": sales_force_name,
      "P_COMPANY": company,
      "P_EDELWEISS": edelweiss,
      "P_EXTERNAL_CHECKBOX": external_checkbox,
      "P_NOTES": notes,
      "P_ENTERED_BY": entered_by,
      "P_UPDATED_BY": updated_by,
      "P_START_DATE": start_date,
      "P_END_DATE": end_date,
      "P_STATUS": status,
      "P_SALES_FORCE_ID": sales_force_id
    };
    console.log('payload' + JSON.stringify(payload));

    return payload;
  };

  PageModule.prototype.preparePayload_InsertDIVData = function (
    sf_div_id,
    division_number,
    division_name,
    external_checkbox,
    notes,
    entered_by,
    updated_by,
    start_date,
    end_date,
    status,
    sf_maintenance_id) {

    if (sf_div_id == 'undefined' || sf_div_id == null) {
      sf_div_id = '';
    }
    if (division_number == 'undefined' || division_number == null) {
      division_number = '';
    }
    if (division_name == 'undefined' || division_name == null) {
      division_name = '';
    }
    if (external_checkbox == 'undefined' || external_checkbox == null) {
      external_checkbox = '';
    }
    if (notes == 'undefined' || notes == null) {
      notes = '';
    }
    if (entered_by == 'undefined' || entered_by == null) {
      entered_by = '';
    }
    if (updated_by == 'undefined' || updated_by == null) {
      updated_by = '';
    }
    if (start_date == 'undefined' || start_date == null) {
      start_date = '';
    }
    if (end_date == 'undefined' || end_date == null) {
      end_date = '';
    }
    if (status == 'undefined' || status == null) {
      status = '';
    }
    if (sf_maintenance_id == 'undefined' || sf_maintenance_id == null) {
      sf_maintenance_id = '';
    }
    var payload = null;
    payload = {
      "P_SF_MAINTENANCE_ID": sf_div_id,
      "P_SALES_FORCE_NUMBER": division_number,
      "P_SALES_FORCE_NAME": division_name,
      "P_EXTERNAL_CHECKBOX": external_checkbox,
      "P_NOTES": notes,
      "P_ENTERED_BY": entered_by,
      "P_UPDATED_BY": updated_by,
      "P_START_DATE": start_date,
      "P_END_DATE": end_date,
      "P_STATUS": status,
      "P_SALES_FORCE_ID": sf_maintenance_id
    };
    console.log('payload' + JSON.stringify(payload));

    return payload;
  };



  PageModule.prototype.preparePayload_DeleteLine = function (
    rowid,) {
    var payload = null;
    //console.log(sfmaintenanceid in delete function" + rowid);
    payload = '{"sf_maintenance_id":"' + rowid + '" }';
    return payload;
  };



  return PageModule;
});
