/**
 * Copyright (c)2020, 2022, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */
define(['knockout',
  'ojs/ojknockout-keyset',
  'ojs/ojarraytreedataprovider'
], function (ko, keySet, ArrayTreeDataProvider) {
  'use strict';

  let navigationMenu = [
    {
      "name": "Sales Force Maintenance",
      "id": "main",
      "icon": "",
      "node": "parent"
    },
    {
      "name": "Assign Account Type",
      "id": "assignAcntType",
      "icon": "",
      "node": "parent"
    },
    {
      "name": "Sales Force Mapping",
      "id": "accountsmapping",
      "icon": "",
      "node": "parent"
    },
    {
      "name": "Assign/Override Sales Force",
      "id": "accountassign",
      "icon": "",
      "node": "parent"
    },
    {
      "name": "Distribution Channel",
      "id": "distribution",
      "icon": "",
    },
    {
      "name": "Assign Distribution Channel",
      "id": "assigndistribution",
      "icon": "",
    },
    {
      "name": "Default/ Unassign Code",
      "id": "",
      "icon": "",
      "node": "parent",
      "items": [
        {
          "name": "Default Distribution",
          "id": "child1",
          "icon": ""
        },
        {
          "name": "Default / Unassign Sales Force",
          "id": "child2",
          "icon": ""
        }
      ]
    }];
  var PageModule = function PageModule() {
    this.metadata = {
      navigationMenu: navigationMenu
    };
    PageModule.prototype.getMetadata = function () {
      return this.metadata;
    };
    PageModule.prototype.getNavigationContent = function (metadata) {
      if (this.navigationContent === undefined) {
        this.navigationContent = ko.observable(new ArrayTreeDataProvider(
          this._getNavigationData(
            metadata.navigationMenu), {
          keyAttributes: 'attr.id'
        }));
      }
      return this.navigationContent;
    };
    PageModule.prototype._getNavigationData = function (menu) {
      var navData = [],
        self = this;

      for (var i = 0; i < menu.length; i++) {
        var menuItem = {};
        var origMenuItem = menu[i];
        if (typeof origMenuItem === "object") {
          menuItem["attr"] = {
            "id": origMenuItem.id,
            "name": origMenuItem.name,
            "icon": origMenuItem.icon,
            "node": origMenuItem.node
          };
        }
        if (origMenuItem.items && origMenuItem.items.length > 0)
          menuItem["children"] = this._getNavigationData(origMenuItem.items);
        navData.push(menuItem);
      }
      return navData;
    };

    PageModule.prototype.itemSelectable = function (context) {
      return context['leaf'];
    };

    this.navlistExpanded = new keySet.ObservableKeySet();

  };


  return PageModule;
});
