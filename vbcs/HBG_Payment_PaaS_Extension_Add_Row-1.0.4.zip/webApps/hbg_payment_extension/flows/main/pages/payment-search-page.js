define([], () => {
  'use strict';

  class PageModule {

  }
  PageModule.prototype.getsysdate = function () {
    return new Date().toISOString();
  };
  
  PageModule.prototype.dateformatter = function (date) {
    if (date !== "" && date !== null && date !== "undefined") {
      var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
        "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
      var t = new Date(date);
      return t.getFullYear() + '-' + t.getMonth() + '-' + t.getDate();
    } else {
      return "";
    }
  };

  PageModule.prototype.log = function (arg1) {
    console.log("---------------LOG !!! ----------------");
    console.log(arg1);
  };

  return PageModule;
});
