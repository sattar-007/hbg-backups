define([], () => {
  'use strict';

  class PageModule {
  }
  
  PageModule.prototype.getlocaldate = function(Inputdate) {
     var todaydate = new Date(Inputdate);
     var locale = 'en-US';
  return todaydate.toLocaleDateString(locale);
  
  };
  return PageModule;
});
