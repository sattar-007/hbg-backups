define(['knockout', 'ojs/ojkeyset', 'ojs/ojarraydataprovider'], function (ko, keySet, arrayDataProvider) {
  "use strict";

  var PageModule = function PageModule() {
    this.arrayvalues = ko.observableArray();
    this.selectedItems = ko.observable({
      row: new keySet.KeySetImpl(),
      column: new keySet.KeySetImpl()
    });
  };

  PageModule.prototype.getsysdate = function () {
    return new Date().toISOString();
  };
  PageModule.prototype.statusLOV = function () {
    var arr = [
      {
        "Status": "Open"
      },
      {
        "Status": "Closed"
      },
      {
        "Status": "Hold"
      },
      {
        "Status": "All"
      }
    ];

    return arr;
  };


  PageModule.prototype.distinctvalcheck = function (data) {
    var obj = {
      "Status": "",
      "arr": []
    };
    const uniqval = [... new Set(data.map(JSON.stringify))].map(JSON.parse);
    let res = uniqval.map(function (elem) {
      return elem.account_number;
    }).join(",");
    var arryval = res.split(',');
    var a = [... new Set(arryval)];
    if (a.length > 0) {
      let accobj = {};
      for (let i = 0; i < a.length; i++) {
        accobj = {
          "AccNbr": a[i]
        };
        obj.arr.push(accobj);
      }
      obj.Status = false;
      return obj;
    } else {
      obj.Status = true;
      return obj;
    }
  };

  PageModule.prototype.getDistinctAccounts = function (data) {

    const unique = [...new Map(data.map((m) => [m.account_number, m])).values()];

    var array = [];

    for (let i = 0; i < unique.length; i++) {
      let accobj = {};
      accobj = {
        "AccNbr": unique[i].account_number,
        "AccName": unique[i].account_name
      };
      array.push(accobj);
    };

    return array.sort();
  };


  PageModule.prototype.deleteDuplicates = function (data) {

    const unique = [...new Map(data.map((m) => [m.trx_key, m])).values()];

    return unique;
  };



  PageModule.prototype.selectedChangedListener = function (selected) {
    // console.log('Inside selectedChange ' + Array.from(selected.row._keys));
    var list = Array.from(selected.row._keys);
    if (list.length == 2) {
      this.arrayvalues(list);
    };
    console.log('Inside selectedChange ' + Array.from(selected.row._keys));
  };

  PageModule.prototype.getSelectedItems = function () {
    return this.selectedItems;
  };


  PageModule.prototype.setbetweenrows = function (data) {
    var arr = [];
    var trxKeyArr = [];
    var sortKeyArr = [];
    this.arrayvalues().sort();
    // for (var i = this.arrayvalues()[0]; i <= this.arrayvalues()[1]; i++) {
    //   arr.push(i);
    // } 
    var selectedData = [];
    var finalSelectedData = [];

    selectedData = data.filter((item1) => {
      return this.arrayvalues().some((item2) => {
        return item1.trx_key === item2;
      });
    });

    for (let i = 0; i < selectedData.length; i++) {
      sortKeyArr.push(selectedData[i].sort_key);
    };
    sortKeyArr.sort();
    for (let i = sortKeyArr[0]; i <= sortKeyArr[1]; i++) {
      arr.push(i);
    }
    finalSelectedData = data.filter((item1) => {
      // console.log('item1.sort_key is ' + item1.sort_key);
      return arr.some((item2) => {
        // console.log('item1.sort_key is ' + item1.sort_key + "item2 "+ item2);
        return item1.sort_key == item2;
      });
    });

    finalSelectedData.sort();
    for (let i = 0; i < finalSelectedData.length; i++) {
      trxKeyArr.push(finalSelectedData[i].trx_key);
    };


    this.selectedItems({
      row: new keySet.KeySetImpl(trxKeyArr),
      column: new keySet.KeySetImpl()
    });

  };


  PageModule.prototype.selectAll = function (data) {

    // let k = new keySet.AllKeySetImpl();
    // k.addAll();
    // this.selectedItems({
    //   row: new keySet.KeySetImpl(k),
    //   column: new keySet.KeySetImpl()
    // });
    // this.selectedItems({
    //   row: new keySet.KeySetImpl(data.row.addAll()),
    //   column: new keySet.KeySetImpl()
    // });

    var trxKeyArr = [];
    for (let i = 0; i < data.length; i++) {
      trxKeyArr.push(data[i].trx_key);
    };
    this.selectedItems({
      row: new keySet.KeySetImpl(trxKeyArr),
      column: new keySet.KeySetImpl()
    });
  };

  PageModule.prototype.clearSelection = function () {

    this.selectedItems({
      row: new keySet.KeySetImpl(),
      column: new keySet.KeySetImpl()
    });
  };

  PageModule.prototype.sortByKey = function (array, key, direction) {

    var seq = 100;
    var resAraay = [];

    if (direction == 'ascending') {
      resAraay = array.sort(function (a, b) {
        var x = a[key];
        var y = b[key];

        if (typeof x == "string") {
          x = ("" + x).toLowerCase();
        }
        if (typeof y == "string") {
          y = ("" + y).toLowerCase();
        }

        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
      });
    }


    if (direction == 'descending') {
      resAraay = array.sort(function (a, b) {
        var x = a[key];
        var y = b[key];

        if (typeof x == "string") {
          x = ("" + x).toLowerCase();
        }
        if (typeof y == "string") {
          y = ("" + y).toLowerCase();
        }

        return ((x > y) ? -1 : ((x < y) ? 1 : 0));
      });
    }



    for (let i = 0; i < resAraay.length; i++) {

      seq++;
      resAraay[i].sort_key = seq;

    }

    return resAraay;
  };

  PageModule.prototype.filterData = function (selected, data, selectedKeys) {
    var keys = [];
    var filteredData = [];
    if (selected.row.isAddAll()) {
      var iterator = selected.row.deletedValues();
      iterator.forEach(function (key) {
        keys.push(key);
      });
      filteredData = data.filter(function (obj) {
        return !keys.some(function (obj2) {
          return obj.trx_key == obj2;
        });
      });
    }
    else {
      filteredData = data.filter(function (obj) {
        return selectedKeys.some(function (obj2) {
          return obj.trx_key == obj2;
        });
      });
    }
    var array = [];

    for (let i = 0; i < filteredData.length; i++) {
      array.push(filteredData[i].amount);
    }
    const sum = array.reduce((partialSum, a) => partialSum + a, 0);
    if (sum < 0) {
      document.getElementById("db_select_total").style.color = 'red';
    }
    else {
      document.getElementById("db_select_total").style.color = 'black';
    }

    var obj = {
      "data": filteredData,
      "count": sum
    };

    return obj;
  };

  // PageModule.prototype.checkboxselectAction = function () {
  //   document.getElementById('invoice').value = ['Y'];
  //   document.getElementById('credits').value = ['Y'];
  //   document.getElementById('claims').value = ['Y'];
  // };

  PageModule.prototype.checkboxdeselectAction = function () {
    document.getElementById('invoice').value = [];
    document.getElementById('credits').value = [];
    document.getElementById('claims').value = [];
    document.getElementById('Unapp_Receipts').value = [];
  };

  PageModule.prototype.sumcol = function (amount, amountapp) {
    if (typeof amount !== "undefined" && typeof amountapp !== "undefined") {
      var sum = amount - amountapp;
      var result = sum.toFixed(2);
      return Number(result);
    } else {
      return null;
    }
  };


  PageModule.prototype.getColor = function (amount) {


    if (typeof amount != 'undefined') {
      var out = amount;
      const formatter = new Intl.NumberFormat('en-US', {
        // style: 'currency',
        currency: 'USD',
        // These options are needed to round to whole numbers if that's what you want.
        minimumFractionDigits: 2, // (this suffices for whole numbers, but will print 2500.10 as $2,500.1)
        // maximumFractionDigits: 0, // (causes 2500.99 to be printed as $2,501)
      });


      if (amount < 0) {
        amount = Math.abs(amount);
        amount = amount.toFixed(2);
        // console.log('amount ' + amount);
        // amount = Number(amount).toLocaleString("en-US");

        // console.log(formatter.format(amount));
        amount = formatter.format(amount);
        // out = 0-amount;
        out = '(' + amount + ')';
      }
      else {
        amount = Number(amount).toFixed(2);

        // out = Number(amount).toLocaleString("en-US");

        out = formatter.format(amount);
      }
      return out;
    }

  };

  PageModule.prototype.getTrxType = function (data) {
    // console.log('Inside getTransactionCodes ' + data.length);
    var array = [];
    var resArray = [];
    for (let i = 0; i < data.length; i++) {
      array.push(data[i].tran_type);
    };
    array = array.filter((item,
      index) => array.indexOf(item) === index);

    for (let i = 0; i < array.length; i++) {
      let trxTypeObj = {};
      trxTypeObj = {
        "TrxType": array[i]
      };
      resArray.push(trxTypeObj);
    };

    // console.log('Inside getTransactionCodes 2 ' + resArray.length);
    return resArray.sort();
  };


  PageModule.prototype.CollapseTrxRequest = function (sessionId, submitted_by, process_id, comments) {

    var jsonString;
    jsonString = '{"sessionId":"' + sessionId + '", "submitted_by":"' + submitted_by + '", "comments":"' + comments + '", "transaction_run_id": "' + process_id + '"}';


    return jsonString;
  };

  PageModule.prototype.applyFontColor = function (acct_bal, claim_total, credit_total, unapp_amt) {

    if (claim_total < 0) {
      // console.log('Inside sum < 0 '+sum);
      document.getElementById("db_claim_total").style.color = 'Red';
    };
    if (acct_bal < 0) {
      document.getElementById("db_acct_bal").style.color = 'Red';
    };

    if (credit_total < 0) {
      document.getElementById("db_credit_total").style.color = 'Red';
    };

    if (unapp_amt < 0) {
      document.getElementById("db_unapp_amt_txt").style.color = 'Red';
    };

  };

  PageModule.prototype.arrayToString = function (array) {

    return array.toString();

    // var arr;
    // if (array == '') {
    //   return null;
    // }
    // else {

    //   for (let i = 0; i < array.length; i++) {
    //     if (i == 0)
    //       arr = "" + array[i] + "";
    //     else
    //       arr = arr + "," + array[i]+"";
    //   }

    //   return arr;
    // }

  }
  return PageModule;
});