define([], () => {
  'use strict';

  class PageModule {
    StringigyArray(val) {
      return val.toString();
    }

    progresspanSHOW() {
      document.getElementById("progress").style.display = 'block';
    }

    progresspanHIDE() {
      document.getElementById("progress").style.display = 'none';
    }
  }

  return PageModule;
});
