define([], () => {
  'use strict';

  class PageModule {
    NavigationToSFPage(url) {
      window.location.href = url;
    }
  }

    PageModule.prototype.dateformatter = function (date) {
    if (date !== "" && date !== null && date !== "undefined") {
      var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
        "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
      var t = new Date(date);
      // return t.getFullYear() + '-' + t.getMonth() + '-' + t.getDate();
      return t;
    } else {
      return "";
    }
  };

  return PageModule;
});
