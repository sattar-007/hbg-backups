define([], () => {
  'use strict';

  class PageModule {

  }

    PageModule.prototype.validateText = function () {
    return [{
      validate: (value) => {
        // if (value == null || String(value) == "") {
        //   throw new Error("This is a mandatory field.");
        // }

        // var pattern = new RegExp(/[a-zA-Z0-9]+$/);
        // var pattern = new RegExp(/^[a-zA-Z]{5,7}$/);

        // var pattern = new RegExp(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/);

        // var validValue = pattern.test(value);

        // if (!validValue) {
          // throw new Error("Please enter alphabets and numbers only.");
          // throw new Error("Please enter atleast 3 characters.");
        // }
      },
      getHint: () => {
        return "Please enter atleast 3 characters.";
      }
    }];
  };
  
  return PageModule;
});
