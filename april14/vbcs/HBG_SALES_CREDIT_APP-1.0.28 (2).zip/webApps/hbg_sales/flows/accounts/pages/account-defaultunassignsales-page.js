define([], () => {
  'use strict';

  class PageModule {
    getsysdate (){
    return new Date().toISOString();
  };
}
    PageModule.prototype.getstatusvalidated = function (startdate, enddate) {
    var sysdate = new Date().toISOString();
    var status = "";

    if (enddate !== "" && enddate !== null && typeof enddate !== "undefined") {
      if (startdate <= sysdate && enddate > sysdate) {
        status = "Active";
      } else if (startdate > sysdate && enddate <= sysdate) {
        status = "Inactive";
      } else {
        status = "Inctive";
      }
    } else if ((enddate === "" || enddate === null || typeof enddate === "undefined") && startdate <= sysdate) {
      status = "Active";
    } else {
      status = "Inctive";
    }
    return status;
  };

  PageModule.prototype.dateformatter = function (date) {
    if (date !== "" && date !== null && date !== "undefined") {
      // var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
      //   "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
      // var t = new Date(date);
      // return t.getFullYear() + '-' + t.getMonth() + '-' + t.getDate();
      let yourDate = new Date(date);
      var result = yourDate.toISOString().split('T')[0];
      return result;
    } else {
      return "";
    }
  };

return PageModule;
});
