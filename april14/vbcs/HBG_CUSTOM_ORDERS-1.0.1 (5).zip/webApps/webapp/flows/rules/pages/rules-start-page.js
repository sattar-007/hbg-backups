define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.getsysdate = function () {
    return new Date().toISOString();
  };
  PageModule.prototype.dateformatter = function (date) {
    if (date !== "" && date !== null && date !== "undefined") {
      let yourDate = new Date(date);
      var result = yourDate.toISOString().split('T')[0];
      return result;
    } else {
      return "";
    }
  };

  PageModule.prototype.validateText = function () {
    return [{
      validate: (value) => {
        if (value == null || String(value) == "") {
          throw new Error("This is a mandatory field.");
        }

        var pattern = new RegExp(/[0-9]+$/);
        var validValue = pattern.test(value);

        if (!validValue) {
          throw new Error("Sequence Cant be Negative.");
        }
      },
      getHint: () => {
        return "Special characters are not allowed";
      }
    }];
  };

  return PageModule;
});
