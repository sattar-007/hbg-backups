define([], () => {
  'use strict';

  class PageModule {
    StringigyArray(val) {
      return val.toString();
    }

    progresspanSHOW() {
      document.getElementById("progress").style.display = 'block';
    }

    progresspanHIDE() {
      document.getElementById("progress").style.display = 'none';
    }

    validateSearch(searchObj) {

      //         "accountNumber": "string",
      //         "cat1Code": "string",
      //         "Cat2Code": "string",
      //         "ExtAccountNumber": "string",
      //         "itemString": "string",
      //         "OrganizationName": "string",
      //         "OwnerCode": "string",
      //         "p_apply_reson_code": "string",
      //         "p_cat1": "string",
      //         "p_cat2": "string",
      //         "p_client_account_type": "string",
      //         "p_cust_account_id": "string",
      //         "p_default_account_type": "string",
      //         "p_ex_cust_account_id": "string",
      //         "p_from_ord_net_value": "string",
      //         "p_from_order": "number",
      //         "p_from_ordered_qty": "string",
      //         "p_hdr_reason_code": "string",
      //         "p_header_id": "string",
      //         "p_invetory_item_id": "string",
      //         "p_item_number": "string",
      //         "p_line_status": "string",
      //         "p_offer_code": "string",
      //         "p_oic_run_id": "string",
      //         "p_order_number": "string",
      //         "p_order_status": "string",
      //         "p_org_name": "string",
      //         "p_organization_id": "string",
      //         "p_organization_id_dummy": "string",
      //         "p_owner_id": "string",
      //         "p_party_site_id": "string",
      //         "p_po_number": "string",
      //         "p_received_from_date": "string",
      //         "p_received_to_date": "string",
      //         "p_release_reason_code": "string",
      //         "p_rpg_grp": "string",
      //         "p_to_ord_net_value": "string",
      //         "p_to_order": "number",
      //         "p_to_ordered_qty": "string",
      //         "partySiteName": "string",
      //         "ReportingGroupCode": "string"


      if ((searchObj.p_cust_account_id !== "" && searchObj.p_cust_account_id !== null && typeof searchObj.p_cust_account_id !== "undefined") || (searchObj.p_hdr_reason_code !== "" && searchObj.p_hdr_reason_code !== null && typeof searchObj.p_hdr_reason_code !== "undefined") || (searchObj.p_invetory_item_id !== "" && searchObj.p_invetory_item_id !== null && typeof searchObj.p_invetory_item_id !== "undefined") || (searchObj.p_release_reason_code !== "" && searchObj.p_release_reason_code !== null && typeof searchObj.p_release_reason_code !== "undefined") || (searchObj.p_line_status !== "" && searchObj.p_line_status !== null && typeof searchObj.p_line_status !== "undefined") || (searchObj.p_order_status !== "" && searchObj.p_order_status !== null && typeof searchObj.p_order_status !== "undefined") || (searchObj.p_organization_id !== "" && searchObj.p_organization_id !== null && typeof searchObj.p_organization_id !== "undefined") || (searchObj.p_received_from_date !== "" && searchObj.p_received_from_date !== null && typeof searchObj.p_received_from_date !== "undefined") || (searchObj.p_received_to_date !== "" && searchObj.p_received_to_date !== null && typeof searchObj.p_received_to_date !== "undefined") || (searchObj.p_to_ordered_qty !== "" && searchObj.p_to_ordered_qty !== null && typeof searchObj.p_to_ordered_qty !== "undefined") || (searchObj.p_from_ordered_qty !== "" && searchObj.p_from_ordered_qty !== null && typeof searchObj.p_from_ordered_qty !== "undefined") || (searchObj.p_ex_cust_account_id !== "" && searchObj.p_ex_cust_account_id !== null && typeof searchObj.p_ex_cust_account_id !== "undefined") || (searchObj.p_header_id !== "" && searchObj.p_header_id !== null && typeof searchObj.p_header_id !== "undefined") || (searchObj.p_cat1 !== "" && searchObj.p_cat1 !== null && typeof searchObj.p_cat1 !== "undefined") || (searchObj.p_cat2 !== "" && searchObj.p_cat2 !== null && typeof searchObj.p_cat2 !== "undefined") || (searchObj.p_owner_id !== "" && searchObj.p_owner_id !== null && typeof searchObj.p_owner_id !== "undefined") || (searchObj.p_rpg_grp !== "" && searchObj.p_rpg_grp !== null && typeof searchObj.p_rpg_grp !== "undefined") || (searchObj.p_party_site_id !== "" && searchObj.p_party_site_id !== null && typeof searchObj.p_party_site_id !== "undefined") || (searchObj.p_apply_reson_code !== "" && searchObj.p_apply_reson_code !== null && typeof searchObj.p_apply_reson_code !== "undefined") || (searchObj.p_from_ord_net_value !== "" && searchObj.p_from_ord_net_value !== null && typeof searchObj.p_from_ord_net_value !== "undefined") || (searchObj.p_offer_code !== "" && searchObj.p_offer_code !== null && typeof searchObj.p_offer_code !== "undefined") || (searchObj.p_to_ord_net_value !== "" && searchObj.p_to_ord_net_value !== null && typeof searchObj.p_to_ord_net_value !== "undefined") || (searchObj.p_org_name !== "" && searchObj.p_org_name !== null && typeof searchObj.p_org_name !== "undefined") || (searchObj.p_po_number !== "" && searchObj.p_po_number !== null && typeof searchObj.p_po_number !== "undefined") || (searchObj.p_order_number !== "" && searchObj.p_order_number !== null && typeof searchObj.p_order_number !== "undefined") || (searchObj.p_default_account_type !== "" && searchObj.p_default_account_type !== null && typeof searchObj.p_default_account_type !== "undefined") || (searchObj.p_client_account_type !== "" && searchObj.p_client_account_type !== null && typeof searchObj.p_client_account_type !== "undefined") || (searchObj.p_from_order !== "" && searchObj.p_from_order !== null && typeof searchObj.p_from_order !== "undefined") || (searchObj.p_to_order !== "" && searchObj.p_to_order !== null && typeof searchObj.p_to_order !== "undefined")) {
        return true;
      } else {
        return false;
      }
    }
  }

  return PageModule;
});
