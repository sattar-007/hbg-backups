define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.getlocaldate1 = function(Inputdate) {
     var todaydate = new Date(Inputdate);
     var locale = 'en-US';
  return todaydate.toLocaleDateString(locale);
  
  };
  

      PageModule.prototype.dateformatter = function (date) {
    if (date !== "" && date !== null && date !== "undefined") {
      var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
        "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
      var t = new Date(date);
      return t.getFullYear() + '-' + t.getMonth() + '-' + t.getDate();
    } else {
      return "";
    }
  };

  PageModule.prototype.getCurrMonth = function() {
     var todaydate = new Date();
  return todaydate.toISOString();
  
  };

  


  PageModule.prototype.preparePayload_UpdateDateORDSObj = function (
    createRule) {
    if(createRule.owner_name == 'undefined' || createRule.owner_name == null)
    {
      createRule.owner_name = '';
    }
	 if(createRule.reporting_group == 'undefined' || createRule.reporting_group == null)
    {
      createRule.reporting_group = '';
    }
	if(createRule.category_1 == 'undefined' || createRule.category_1 == null)
    {
      createRule.category_1 = '';
    }
	if(createRule.category_2 == 'undefined' || createRule.category_2 == null)
    {
      createRule.category_2 = '';
    }
	if(createRule.item_number == 'undefined' || createRule.item_number	== null)
    {
      createRule.item_number = '';
    }
	if(createRule.organization == 'undefined' || createRule.organization == null)
    {
      createRule.organization = '';
    }
	if(createRule.account_number == 'undefined' || createRule.account_number == null)
    {
      createRule.account_number = '';
    }
	if(createRule.ship_to_site == 'undefined' || createRule.ship_to_site == null)
    {
      createRule.ship_to_site = '';
    }
	if(createRule.country == 'undefined' || createRule.country == null)
    {
      createRule.country = '';
    }
	if(createRule.state == 'undefined' || createRule.state == null)
    {
      createRule.state = '';
    }
	if(createRule.hold_name == 'undefined' || createRule.hold_name == null)
    {
      createRule.hold_name = '';
    }
	if(createRule.hold_comments == 'undefined' || createRule.hold_comments == null)
    {
      createRule.hold_comments = '';
    }
	if(createRule.comments == 'undefined' || createRule.comments == null)
    {
      createRule.comments = '';
    }
	if(createRule.auto_release_flag == 'undefined' || createRule.auto_release_flag == null)
    {
      createRule.auto_release_flag = '';
    }
	if(createRule.start_date == 'undefined' || createRule.start_date == null)
    {
      createRule.start_date = '';
    }
	else 
	{
	  createRule.start_date = createRule.start_date.substr(0,10);
	}
	if(createRule.end_date == 'undefined' || createRule.end_date == null)
    {
      createRule.end_date = '';
    }
	else 
	{
	  createRule.end_date = createRule.end_date.substr(0,10);
	}
  if(createRule.department == 'undefined' || createRule.department == null)
    {
      createRule.department = '';
    }
   if(createRule.zip_code == 'undefined' || createRule.zip_code == null)
    {
      createRule.zip_code = '';
    }

    var payload = null;
    payload = '{"p_owner":"' + createRule.owner_name +
    '",				"p_reporting_group":"' + createRule.reporting_group + 
    '",				"p_category1":"' + createRule.category_1 + 
    '",				"p_category2":"' + createRule.category_2 + 
	'",				"p_item_number":"' + createRule.item_number + 
	'",				"p_organization":"' + createRule.organization + 
	'",				"p_account_number":"' + createRule.account_number + 
	'",				"p_shipto":"' + createRule.ship_to_site + 
	'",				"p_country":"' + createRule.country + 
	'",				"p_state":"' + createRule.state + 
	'",				"p_holdname":"' + createRule.hold_name + 
	'",				"p_hold_comments":"' + createRule.hold_comments + 
	'",				"p_start_date":"' + createRule.start_date + 
	'",				"p_comments":"' + createRule.comments +
	'",				"p_autoreleaseflag":"' + createRule.auto_release_flag + 	
	'",				"p_end_date":"' + createRule.end_date + 
  '",				"p_created_by":"' + createRule.created_by + 
  '",				"p_last_updated_by":"' + createRule.last_updated_by +
  '",				"p_department":"' + createRule.department + 
  '",				"p_zipcode":"' + createRule.zip_code +  '" }';
    return payload;
  };

PageModule.prototype.ValidateCreatePayload = function (createRuleValidation) {

        var payload = 'SUCCESS';
        if (createRuleValidation.hold_name == null || createRuleValidation.hold_name == '' || createRuleValidation.hold_name == 'undefined') {
            payload = 'Hold Name is Mandatory';
        } else if (createRuleValidation.start_date == null || createRuleValidation.start_date == '' || createRuleValidation.start_date == 'undefined') {
            payload = 'Start Date is Mandatory';
        } else if (createRuleValidation.end_date < createRuleValidation.start_date) {
            payload = 'You need to enter the end date later than start date';
        } else if ((createRuleValidation.owner_name == null || createRuleValidation.owner_name == '' || createRuleValidation.owner_name == 'undefined') && (createRuleValidation.item_number == null || createRuleValidation.item_number == '' || createRuleValidation.item_number == 'undefined') && (createRuleValidation.organization == null || createRuleValidation.organization == '' || createRuleValidation.organization == 'undefined') && (createRuleValidation.country == null || createRuleValidation.country == '' || createRuleValidation.country == 'undefined') ) {
           payload = 'Rule must populate one of the field like Owner, Item, Organization or Country';
        }
        return payload;
    };

  return PageModule;
});
