define(['knockout', 'ojs/ojkeyset'], function (ko, keySet) {
  "use strict";

  var PageModule = function PageModule() 
  {
    this.selectedItems = ko.observable({
      row: new keySet.KeySetImpl(),
      column: new keySet.KeySetImpl()
    });
  };
 
PageModule.prototype.getSelectedItems = function() {
  return this.selectedItems;
};
   
 PageModule.prototype.selectedChangedListener = function (selected) {
    var selectionText = '';

    if (selected.row.isAddAll()) {
      var iterator = selected.row.deletedValues();
      iterator.forEach(function (key) {
        selectionText = selectionText.length === 0 ? key :
          selectionText + ', ' + key;
      });

      if (iterator.size > 0) {
        selectionText = ' except row key(s): ' + selectionText;
      }
      selectionText = 'All rows are selected' +
        selectionText;
    } else {
      if (selected.row.values().size > 0) {
        selected.row.values().forEach(function (key) {
          selectionText += (selectionText.length === 0 ? key :
            ', ' + key);
        });
        selectionText =  selectionText;
      }

    }
    return selectionText;
  };

 


PageModule.prototype.PrepareDeletePayLoad = function(p_country_id,p_country_group_id)
{

 var payload = null;
    payload = '{"p_country_id":"' + p_country_id +
    '",				"p_country_group_id":"' + p_country_group_id +  '" }';
    return payload;
};

 PageModule.prototype.preparePayload_UpdateCountryGroup = function (
    updateGroup) {

      if(updateGroup.comments == null)
    {
     updateGroup.comments = '';
    }

      if(updateGroup.country_group_name == null)
    {
     updateGroup.country_group_name = '';
    }
    var payload = null;
    payload = '{"p_country_group_id":"' + updateGroup.country_group_id +
    '",				"p_comments":"' + updateGroup.comments + 
    '",				"p_country_group_name":"' + updateGroup.country_group_name + 
    '",				"p_enabled_flag":"' + updateGroup.enabled_flag +  '" }';
    return payload;
  };
  
   PageModule.prototype.preparePayload_AssignCountry = function (
    AddCountry,CountryGroup,p_created_by,p_last_updated_by) {

      if(p_created_by == null)
    {
     p_created_by = '';
    }

      if(p_last_updated_by == null)
    {
     p_last_updated_by = '';
    }
    var payload = null;
    payload = '{"p_country_group_id":"' + CountryGroup.country_group_id +
    '",				"p_country_id":"' + AddCountry.country_id + 
    '",				"p_created_by":"' + p_created_by + 
    '",				"p_last_updated_by":"' + p_last_updated_by +  '" }';
    return payload;
  };
  
PageModule.prototype.PrepareCreateCountryGroup = function(CountryGroup,p_created_by,p_last_updated_by)
{

 if(p_created_by == null)
    {
     p_created_by = '';
    }

      if(p_last_updated_by == null)
    {
     p_last_updated_by = '';
    }

     if(CountryGroup.country_group_code  == null || CountryGroup.country_group_code  == 'undefined')
    {
     CountryGroup.country_group_code  = '';
    }

      if(CountryGroup.country_group_name == null || CountryGroup.country_group_name  == 'undefined')
    {
     CountryGroup.country_group_name = '';
    }

     if(CountryGroup.comments  == null || CountryGroup.comments  == 'undefined')
    {
     CountryGroup.comments  = '';
    }
    if(CountryGroup.enabled_flag == null || CountryGroup.enabled_flag  == 'undefined')
    {
     CountryGroup.enabled_flag = '';
    }

 var payload = null;
    payload = '{"p_country_group_code":"' + CountryGroup.country_group_code +
    '",				"p_country_group_name":"' + CountryGroup.country_group_name + 
    '",				"p_comments":"' + CountryGroup.comments + 
    '",				"p_enabled_flag":"' + CountryGroup.enabled_flag + 
    '",				"p_created_by":"' + p_created_by + 
    '",				"p_last_updated_by":"' + p_last_updated_by +  '" }';
    return payload;
};  

PageModule.prototype.PrepareCopyEditCountryGroup = function(CountryGroup,p_created_by,p_last_updated_by)
{

 if(p_created_by == null)
    {
     p_created_by = '';
    }

      if(p_last_updated_by == null)
    {
     p_last_updated_by = '';
    }

	if(CountryGroup.country_group_id  == null || CountryGroup.country_group_id  == 'undefined')
    {
     CountryGroup.country_group_id  = '';
    }
	
     if(CountryGroup.country_group_code  == null || CountryGroup.country_group_code  == 'undefined')
    {
     CountryGroup.country_group_code  = '';
    }

      if(CountryGroup.country_group_name == null || CountryGroup.country_group_name  == 'undefined')
    {
     CountryGroup.country_group_name = '';
    }

     if(CountryGroup.comments  == null || CountryGroup.comments  == 'undefined')
    {
     CountryGroup.comments  = '';
    }
    if(CountryGroup.enabled_flag == null || CountryGroup.enabled_flag  == 'undefined')
    {
     CountryGroup.enabled_flag = '';
    }

 var payload = null;
    payload = '{"p_country_group":"' + CountryGroup.country_group_id +
    '",				"p_country_group_code":"' + CountryGroup.country_group_code + 
    '",				"p_country_group_name":"' + CountryGroup.country_group_name + 
    '",				"p_comments":"' + CountryGroup.comments + 
    '",				"p_enabled_flag":"' + CountryGroup.enabled_flag + 
    '",				"p_created_by":"' + p_created_by + 
    '",				"p_last_updated_by":"' + p_last_updated_by +  '" }';
    return payload;
};  

 
return PageModule; 
}
);
      