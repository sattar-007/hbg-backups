define([], () => {
    'use strict';

    class PageModule {}

  PageModule.prototype.getSysdate = function() {
     var todaydate = new Date();
  return todaydate.toISOString();
  
  };
    PageModule.prototype.ValidateCreatePayload = function (p_create_distributionrule) {

        var payload = 'SUCCESS';
        if (p_create_distributionrule.outcome == null || p_create_distributionrule.outcome == '' || p_create_distributionrule.outcome == 'undefined') {
            payload = 'Outcome is Mandatory';
        } else if (p_create_distributionrule.start_date == null || p_create_distributionrule.start_date == '' || p_create_distributionrule.start_date == 'undefined') {
            payload = 'Start Date is Mandatory';
        } else if ((p_create_distributionrule.country_group == null || p_create_distributionrule.country_group == '' || p_create_distributionrule.country_group == 'undefined') && (p_create_distributionrule.country_code == null || p_create_distributionrule.country_code == '' || p_create_distributionrule.country_code == 'undefined')) {
            payload = 'You need to enter either Country group or Country';
       /* } else if ((p_create_distributionrule.account_number == null || p_create_distributionrule.account_number == '' || p_create_distributionrule.account_number == 'undefined') && (p_create_distributionrule.account_type == null || p_create_distributionrule.account_type == '' || p_create_distributionrule.account_type == 'undefined') && (p_create_distributionrule.default_account_type == null || p_create_distributionrule.default_account_type == '' || p_create_distributionrule.default_account_type == 'undefined')) {
            payload = 'You need to enter either Account Number, Account Type or Default Account Type';*/
        } else if ((p_create_distributionrule.from_pub_date == null || p_create_distributionrule.from_pub_date == '' || p_create_distributionrule.from_pub_date == 'undefined') && (p_create_distributionrule.to_pub_date != null && p_create_distributionrule.to_pub_date != '' && p_create_distributionrule.to_pub_date != 'undefined')) {
            payload = 'From Pub Date is Mandatory if To Pub date is selected';
        } else if ((p_create_distributionrule.to_pub_date == null || p_create_distributionrule.to_pub_date == '' || p_create_distributionrule.to_pub_date == 'undefined') && (p_create_distributionrule.from_pub_date != null && p_create_distributionrule.from_pub_date != '' && p_create_distributionrule.from_pub_date != 'undefined')) {
            payload = 'To Pub Date is Mandatory if From Pub date is selected';
        } else if (p_create_distributionrule.to_pub_date < p_create_distributionrule.from_pub_date) {
            payload = 'You need to enter To Pub date later than From Pub date';
        } else if (p_create_distributionrule.end_date < p_create_distributionrule.start_date) {
            payload = 'You need to enter the end date later than start date';
        } else if ((p_create_distributionrule.item_number == null || p_create_distributionrule.item_number == '' || p_create_distributionrule.item_number == 'undefined') && (p_create_distributionrule.owner == null || p_create_distributionrule.owner == '' || p_create_distributionrule.owner == 'undefined')) {
            payload = 'You need to enter either Item Number or Owner';
      /*  } else if ((p_create_distributionrule.reporting_group == null || p_create_distributionrule.reporting_group == '' || p_create_distributionrule.reporting_group == 'undefined') && (p_create_distributionrule.owner != null && p_create_distributionrule.owner != '' && p_create_distributionrule.owner != 'undefined')) {
            payload = 'You need to enter Reporting Group if Owner is selected';*/
        }
        return payload;
    };


  /*  PageModule.prototype.itemnumber = function(item_number) {
     var p_item_number = 'A';
    for (var i = 0; i < item_number.length; i++) 
    {
        p_item_number = p_item_number + item_number.charAt(i);
     }
  return p_item_number;
  
  };*/

    return PageModule;
});
